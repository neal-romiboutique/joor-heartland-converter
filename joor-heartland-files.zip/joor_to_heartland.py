#!/usr/bin/env python3
"""
JOOR -> Heartland Retail converter for Romi Boutique.  (v7)

Phase 1 (grids):  python3 joor_to_heartland.py grids JOOR_ORDER.csv|.xlsx [-o grids.xlsx]
    One row per (vendor, style, color) in Heartland's official grid-import
    template schema, Generate Items = true, sizes completed per store rules.

Phase 2 (po):     python3 joor_to_heartland.py po JOOR_ORDER.csv|.xlsx ITEMS_EXPORT.csv [-o po.xlsx]
    Joins Heartland's post-import grid/items export back to the JOOR order
    (grid # + size -> Item #) and emits the PO import file.

Accepts BOTH JOOR export formats, auto-detected:
  A) Basic Export (long): csv/tsv/txt/xlsx, header row 1, snake_case columns,
     one row per style/color/size.
  B) Order-to-Size (wide): formatted xlsx PO, metadata block on top, one row
     per style/color with sizes as columns; may contain embedded product
     images, which the grids phase extracts to <output>_images/.

Store conventions encoded below; edit CONFIG to change.
"""
import argparse, csv, math, re, sys, unicodedata
from decimal import Decimal, ROUND_CEILING
from pathlib import Path

# ----------------------------- CONFIG ---------------------------------------
MARGIN = Decimal("2.4")          # retail = MARGIN x unit cost when JOOR has no MSRP
VENDOR_MAP = {                   # raw JOOR seller_account -> Heartland vendor record
    # "Dôen (shopdoen.com)": "DOEN",   # explicit overrides go here
}
SEASON_FROM = "linesheet"        # JOOR column used for Season (long format only)
# Heartland official grid-import template headers (84 cols), verbatim:
TEMPLATE_HEADERS = ['Item Grid #','Description','Long Description','Default Cost','Original Price','Price','Primary Vendor','Color','Category','Size','Style Name','Style Number','Season','Taxable?','Sell on Shopify','Shopify Product Type','Shopify Tags','Shopify Category','Shopify Color','Active fit guide','Tags','Dimension 1','Dimension 1 Values','Dimension 2','Dimension 2 Values','Dimension 3','Dimension 3 Values','Active','Generate Items','Item #','Item Description','Item Default Cost','Item Tags','Item Dynamic Margin','Item Original Price','Item Current Price','Item Active?','Item Track Inventory?','Item Long Description','Item Prompt for description?','Item Prompt for price?','Item Primary Image','Item Use dynamic margin?','Item Primary Vendor','Item Color','Item Category','Item Size','Item Style Name','Item Style Number','Item Season','Item Taxable?','Item Sell on Shopify','Item Shopify Product Type','Item Shopify Tags','Item Shopify Category','Item Shopify Color','Item Active fit guide','Item Weight','Item Weight Unit','Item Width','Item Width Unit','Item Height','Item Height Unit','Item Depth','Item Depth Unit','Item romi boutique Reorder Point','Item romi boutique Target Qty','Item romi boutique Bin Location','Item Shopify Reorder Point','Item Shopify Target Qty','Item Shopify Bin Location','Item Max Retail Reorder Point','Item Max Retail Target Qty','Item Max Retail Bin Location','Item Garmentory Reorder Point','Item Garmentory Target Qty','Item Garmentory Bin Location','Item All Locations Reorder Point','Item All Locations Target Qty','Item All Locations Bin Location','Item Vendor Details Item #','Item Vendor Details Default Cost','Item Vendor Details #','Item Images URL']

# Non-size headers in the wide (Order-to-Size) line table. Anything else with a
# non-empty header between "Country of Origin" and the money columns is a size.
WIDE_NON_SIZE = {"style image", "style name", "style number", "color", "color code",
                 "color comment", "style comment", "materials", "fabrication",
                 "country of origin", "item discount", "units"}
WIDE_NON_SIZE_PREFIXES = ("sugg. retail", "sugg retail", "wholesale", "total")

# ------------------------- text utilities -----------------------------------
def title_caps(s: str) -> str:
    """Word-wise title case, capitalizing after spaces and hyphens,
    keeping letters after apostrophes lowercase (Isabel's, Off-White)."""
    def cap_word(w):
        parts = w.split("-")
        return "-".join(p[:1].upper() + p[1:].lower() if p else p for p in parts)
    return " ".join(cap_word(w) for w in s.strip().split())

def fix_mojibake(s: str) -> str:
    """Repair UTF-8 text that was mis-decoded as Mac Roman / cp1252 upstream
    (e.g. 'D√¥en' -> 'Dôen'). Best effort; returns input if repair fails."""
    if not any(ch in s for ch in ("√", "Ã", "â", "€")):
        return s
    for enc in ("mac_roman", "cp1252"):
        try:
            fixed = s.encode(enc).decode("utf-8")
            if sum(ord(c) > 127 for c in fixed) < sum(ord(c) > 127 for c in s):
                return fixed
        except (UnicodeEncodeError, UnicodeDecodeError):
            continue
    return s

def normalize_vendor(raw: str) -> str:
    raw = fix_mojibake(raw)
    if raw in VENDOR_MAP:
        return VENDOR_MAP[raw]
    name = raw.split(" (")[0]                                   # drop "(shopdoen.com)"
    name = unicodedata.normalize("NFKD", name)
    name = "".join(c for c in name if not unicodedata.combining(c))  # ô -> o
    return name.upper().strip()

def color_code(color: str) -> str:
    words = re.split(r"[\s\-]+", color.strip())
    return "".join(w[0] for w in words if w).upper()

def slug(s: str) -> str:
    return re.sub(r"[^A-Z0-9]+", "-", s.upper()).strip("-")

def _num(v):
    """'1' / 1 / 1.0 / '' -> float or None."""
    if v is None:
        return None
    s = str(v).strip()
    if not s:
        return None
    try:
        return float(s)
    except ValueError:
        return None

# ------------------------- size completion engine ---------------------------
LETTER_LADDER = ["XXXS","XXS","XS","S","M","L","XL","XXL","XXXL","XXXXL"]
LETTER_BASE = ("XS","L")
OS_TOKENS = {"OS","O/S","ONE SIZE","ONESIZE"}

def detect_convention(sizes):
    """Return (name, ladder, base_lo_idx, base_hi_idx) or fallback."""
    up = [s.upper() for s in sizes]
    if all(s in OS_TOKENS for s in up):
        return ("os", ["OS"], 0, 0)
    if all(s in LETTER_LADDER for s in up):
        return ("letters", LETTER_LADDER,
                LETTER_LADDER.index(LETTER_BASE[0]), LETTER_LADDER.index(LETTER_BASE[1]))
    try:
        nums = sorted({int(s) for s in sizes})
    except ValueError:
        return ("unknown", None, None, None)
    lo, hi = nums[0], nums[-1]
    if hi <= 12:
        odd = any(n % 2 for n in nums)
        if odd and hi <= 6:                       # 0,1,2,3,4 style
            ladder = list(range(0, max(hi, 4) + 1))
            return ("numeric-0-4", ladder, ladder.index(0), ladder.index(4))
        if not odd:                                # even 0-10 style
            if hi <= 4:
                print(f"  WARNING: sizes {nums} fit both the 0-10 even and 0-4 "
                      f"conventions; defaulting to 0-10 even. Override manually if wrong.")
            ladder = list(range(0, max(hi, 10) + 1, 2))
            return ("numeric-even-0-10", ladder, 0, ladder.index(10))
        return ("unknown", None, None, None)       # odd sizes above 6: unrecognized
    if 20 <= lo and hi <= 45:                      # denim 24-29 base, step 1
        ladder = list(range(min(lo, 24), max(hi, 29) + 1))
        return ("denim-24-29", ladder, ladder.index(24), ladder.index(29))
    if lo >= 60 and all(n % 5 == 0 for n in nums): # euro 70-90 base, step 5
        ladder = list(range(min(lo, 70), max(hi, 90) + 5, 5))
        return ("euro-70-90", ladder, ladder.index(70), ladder.index(90))
    return ("unknown", None, None, None)

def complete_sizes(ordered_sizes):
    """Continuous ladder span from min(base, ordered) to max(base, ordered)."""
    name, ladder, b_lo, b_hi = detect_convention(ordered_sizes)
    if name == "os":
        return ["OS"], name
    if name == "unknown":
        print(f"  WARNING: unrecognized size convention {sorted(set(ordered_sizes))}; "
              f"using ordered sizes as-is (no completion).")
        return sorted(set(str(s) for s in ordered_sizes)), name
    if name == "letters":
        idxs = [ladder.index(s.upper()) for s in ordered_sizes]
    else:
        idxs = [ladder.index(int(s)) for s in ordered_sizes]
    lo, hi = min(min(idxs), b_lo), max(max(idxs), b_hi)
    return [str(ladder[i]) for i in range(lo, hi + 1)], name

# ------------------------- pricing -------------------------------------------
def ceil_dollars(val) -> int:
    return int(Decimal(str(val)).to_integral_value(rounding=ROUND_CEILING))

def retail_price(unit_cost, sugg_retail=None) -> int:
    """JOOR Sugg. Retail if present, else MARGIN x cost; always ceil to whole $."""
    if sugg_retail:
        return ceil_dollars(sugg_retail)
    return ceil_dollars(Decimal(str(unit_cost)) * MARGIN)

# ------------------------- io: format detection & parsing --------------------
def _load_sheet_rows(path):
    """xlsx -> (worksheet, list-of-list of string cell values). data_only skips formulas."""
    from openpyxl import load_workbook
    wb = load_workbook(path, data_only=True)
    ws = wb.active
    rows = [[("" if c is None else str(c).strip()) for c in r]
            for r in ws.iter_rows(values_only=True)]
    return ws, rows

def _find_meta(rows, label):
    """Find 'Label:' either as its own cell (value = next non-empty cell to the
    right) or embedded 'Label: value' inside one cell."""
    lab = label.lower().rstrip(":")
    for r in rows:
        for i, cell in enumerate(r):
            low = cell.lower()
            if low.rstrip(":") == lab and cell.endswith(":"):
                for nxt in r[i+1:]:
                    if nxt:
                        return nxt
            m = re.match(rf"{re.escape(lab)}\s*:\s*(.+)", low)
            if m:
                return cell.split(":", 1)[1].strip()
    return ""

def parse_order_to_size(path):
    """JOOR 'Order to Size' wide xlsx -> (normalized long rows, images dict)."""
    _, rows = _load_sheet_rows(path)

    # --- header row of the line-item table
    hdr_idx = next((i for i, r in enumerate(rows)
                    if "style number" in [c.lower() for c in r]
                    and "style name" in [c.lower() for c in r]), None)
    if hdr_idx is None:
        sys.exit("ERROR: couldn't find the line-item header row (Style Name / Style Number).")
    hdr = rows[hdr_idx]
    col = {c.lower(): i for i, c in enumerate(hdr) if c}
    size_cols = [(i, c) for i, c in enumerate(hdr) if c
                 and c.lower() not in WIDE_NON_SIZE
                 and not c.lower().startswith(WIDE_NON_SIZE_PREFIXES)]
    ws_col = next((i for c, i in col.items() if c.startswith("wholesale")), None)
    sr_col = next((i for c, i in col.items() if c.startswith(("sugg. retail", "sugg retail"))), None)
    if ws_col is None:
        sys.exit("ERROR: no WholeSale column found in the line-item table.")

    # --- order-level metadata
    vendor_raw = next((c for r in rows[:hdr_idx] for c in r if c), "")
    if vendor_raw.endswith(":") or not vendor_raw:
        vendor_raw = ""
        print("  WARNING: couldn't identify the vendor cell; set VENDOR_MAP or check output.")
    order_no  = _find_meta(rows[:hdr_idx], "PO Number")
    start_ship = _find_meta(rows[:hdr_idx], "Start Ship")
    end_ship   = _find_meta(rows[:hdr_idx], "Complete")
    print(f"  [order-to-size] vendor='{vendor_raw}'  PO={order_no}  "
          f"ship {start_ship} -> {end_ship}  (no linesheet column: Season will be blank)")

    # --- melt wide line rows into the same long dicts the pipeline expects
    long_rows, line_row_idx = [], {}
    for i in range(hdr_idx + 1, len(rows)):
        r = rows[i]
        style_no  = r[col["style number"]] if col["style number"] < len(r) else ""
        style_name = r[col["style name"]] if col["style name"] < len(r) else ""
        if not style_no or not style_name:
            continue                                   # totals / footer rows
        color = r[col["color"]] if col["color"] < len(r) else ""
        line_row_idx[i] = (style_no, color)            # for image anchoring
        for ci, size_label in size_cols:
            qty = _num(r[ci]) if ci < len(r) else None
            if not qty:
                continue
            long_rows.append({
                "seller_account": vendor_raw,
                "style_number":  style_no,
                "style_name":    style_name,
                "color":         color,
                "size":          size_label,
                "quantity":      qty,
                "item_price":    _num(r[ws_col]) or 0,
                "sugg_retail":   _num(r[sr_col]) if sr_col is not None else None,
                "order_number":  order_no,
                "start_date":    start_ship,
                "cancel_date":   end_ship,
                SEASON_FROM:     "",
            })
    images = extract_embedded_images(path, line_row_idx)
    return long_rows, images

def extract_embedded_images(path, line_row_idx):
    """Map embedded product images to (style_number, color) via drawing anchors.
    Returns {(style_no, color): (bytes, media_filename)}. Skips non-line-row
    images (e.g. the JOOR logo in the footer)."""
    import zipfile, xml.etree.ElementTree as ET
    ns = {"xdr": "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing",
          "a":   "http://schemas.openxmlformats.org/drawingml/2006/main",
          "r":   "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
          "rel": "http://schemas.openxmlformats.org/package/2006/relationships"}
    out = {}
    try:
        with zipfile.ZipFile(path) as z:
            drawings = [n for n in z.namelist()
                        if re.fullmatch(r"xl/drawings/drawing\d+\.xml", n)]
            for d in drawings:
                rels_name = re.sub(r"drawings/(drawing\d+\.xml)", r"drawings/_rels/\1.rels", d)
                rid_to_media = {}
                if rels_name in z.namelist():
                    for rel in ET.fromstring(z.read(rels_name)).findall("rel:Relationship", ns):
                        tgt = rel.get("Target", "").replace("../", "xl/")
                        rid_to_media[rel.get("Id")] = tgt
                for anchor in ET.fromstring(z.read(d)):
                    frm = anchor.find("xdr:from", ns)
                    blip = anchor.find(".//a:blip", ns)
                    if frm is None or blip is None:
                        continue
                    row0 = int(frm.find("xdr:row", ns).text)      # 0-indexed anchor row
                    key = line_row_idx.get(row0)                  # rows list is 0-indexed too
                    if key is None:
                        continue                                  # logo/footer image
                    media = rid_to_media.get(blip.get(f"{{{ns['r']}}}embed"))
                    if media and media in z.namelist():
                        out[key] = (z.read(media), Path(media).name)
    except Exception as e:
        print(f"  WARNING: image extraction failed ({e}); continuing without images.")
    return out

def read_joor(path):
    """Read a JOOR export in either format -> (list of long dicts, images dict).
    Auto-detects: Basic Export (long) vs Order-to-Size (wide, formatted xlsx)."""
    p = Path(path)
    if p.suffix.lower() in (".xlsx", ".xlsm"):
        _, rows = _load_sheet_rows(p)
        first_hdr = [h.lower() for h in rows[0]] if rows else []
        if "seller_account" not in first_hdr:                    # wide format
            return parse_order_to_size(p)
        rows = [[c for c in r] for r in rows]
    else:
        raw = p.read_bytes()
        for enc in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
            try:
                text = raw.decode(enc); break
            except UnicodeDecodeError:
                continue
        delim = "\t" if text.splitlines()[0].count("\t") > text.splitlines()[0].count(",") else ","
        rows = list(csv.reader(text.splitlines(), delimiter=delim))
    hdr = [h.strip().lower() for h in rows[0]]
    return [dict(zip(hdr, r)) for r in rows[1:] if any(str(c).strip() for c in r)], {}

def write_xlsx(path, headers, rows, text_cols=()):
    from openpyxl import Workbook
    from openpyxl.styles import Font
    from openpyxl.utils import get_column_letter
    wb = Workbook(); ws = wb.active
    bold = Font(name="Arial", size=10, bold=True); norm = Font(name="Arial", size=10)
    for c, h in enumerate(headers, 1):
        ws.cell(row=1, column=c, value=h).font = bold
    for r_i, row in enumerate(rows, 2):
        for c, h in enumerate(headers, 1):
            v = row.get(h)
            cell = ws.cell(row=r_i, column=c)
            if h in text_cols and v is not None:
                cell.value = str(v); cell.number_format = "@"
            else:
                cell.value = v
            cell.font = norm
    for c, h in enumerate(headers, 1):
        vals = [h] + [str(r.get(h) or "") for r in rows]
        ws.column_dimensions[get_column_letter(c)].width = min(max(len(s) for s in vals) + 2, 34)
    ws.freeze_panes = "A2"
    wb.save(path)

# ------------------------- phase 1: grids ------------------------------------
def build_grids(joor_rows, out_path, images=None):
    groups = {}                                   # (vendor, style#, color) -> data
    for r in joor_rows:
        vendor = normalize_vendor(r["seller_account"])
        key = (vendor, r["style_number"].strip(), title_caps(fix_mojibake(r["color"])))
        g = groups.setdefault(key, {"sizes": [], "cost": r["item_price"],
                                    "sugg_retail": r.get("sugg_retail"),
                                    "style_name_raw": r["style_name"],
                                    "raw_key": (r["style_number"].strip(), r["color"]),
                                    "season": str(r.get(SEASON_FROM, "") or "").strip()})
        g["sizes"].append(str(r["size"]).strip())

    # grid numbers with intra-run collision handling
    codes = {}
    for (vendor, style_no, color) in groups:
        code = color_code(color)
        while (vendor, style_no, code) in codes.values():
            code = slug(color)                    # fall back to full color slug
        codes[(vendor, style_no, color)] = (vendor, style_no, code)

    out_rows = []
    for key, g in groups.items():
        vendor, style_no, color = key
        desc = title_caps(fix_mojibake(g["style_name_raw"]))
        sizes, conv = complete_sizes(g["sizes"])
        price = retail_price(g["cost"], g.get("sugg_retail"))
        src = "JOOR Sugg. Retail" if g.get("sugg_retail") else f"{MARGIN}x cost"
        print(f"  {desc} / {color}: ordered {sorted(set(g['sizes']))} -> "
              f"[{conv}] generated {sizes}  | price ${price} ({src})")
        if not g["season"]:
            print(f"    NOTE: no Season available for this line; fill in manually.")
        row = {h: None for h in TEMPLATE_HEADERS}
        row.update({
            "Item Grid #": "-".join(codes[key]),
            "Description": desc,
            "Default Cost": float(g["cost"]),
            "Price": price,
            "Primary Vendor": vendor,
            "Style Name": f"{desc} in {color}",
            "Style Number": style_no,
            "Season": g["season"] or None,
            "Dimension 1": "Color", "Dimension 1 Values": color,
            "Dimension 2": "Size", "Dimension 2 Values": ",".join(sizes),
            "Active": "true", "Generate Items": "true",
        })
        out_rows.append(row)
    write_xlsx(out_path, TEMPLATE_HEADERS, out_rows,
               text_cols=("Item Grid #", "Style Number"))
    print(f"wrote {out_path} ({len(out_rows)} grid(s))")

    # --- embedded images (Order-to-Size source only)
    if images:
        img_dir = Path(out_path).with_suffix("")
        img_dir = img_dir.parent / (img_dir.name + "_images")
        img_dir.mkdir(exist_ok=True)
        for key, g in groups.items():
            hit = images.get((g["raw_key"][0], g["raw_key"][1]))
            if not hit:
                continue
            data, media_name = hit
            grid_no = "-".join(codes[key])
            ext = Path(media_name).suffix or ".jpg"
            fp = img_dir / f"{grid_no}{ext}"
            fp.write_bytes(data)
            stem = Path(media_name).stem
            print(f"  image: {fp.name}  (JOOR asset: {media_name})")
            print(f"    -> candidate CDN URLs to test in a browser:")
            print(f"       https://itemimages.jooraccess.com/img/image/{stem}")
            print(f"       https://images.jooraccess.com/{media_name}")
        print(f"  extracted {len(images)} product image(s) to {img_dir}/ "
              f"(NOTE: embedded copies are low-res thumbnails)")

# ------------------------- phase 2: PO ---------------------------------------
PO_HEADERS = ["PO #", "PO Vendor", "PO Start Ship", "PO End Ship",
              "Item #", "PO Line Qty", "PO Line Unit Cost"]

def build_po(joor_rows, items_export_path, out_path):
    with open(items_export_path, newline="", encoding="utf-8-sig") as f:
        items = list(csv.DictReader(f))
    by_style, by_grid = {}, {}
    for it in items:
        num = it["Item #"].strip()
        size = it.get("Item Size", "").strip().upper()
        if it.get("Item Style Number") and it.get("Item Color"):
            by_style[(it["Item Style Number"].strip().upper(),
                      it["Item Color"].strip().upper(), size)] = num
        if it.get("Item Grid #"):
            by_grid[(it["Item Grid #"].strip(), size)] = num
    out_rows, missing = [], []
    for r in joor_rows:
        vendor = normalize_vendor(r["seller_account"])
        color = title_caps(fix_mojibake(r["color"]))
        size = str(r["size"]).strip().upper()
        item_no = by_style.get((r["style_number"].strip().upper(), color.upper(), size))
        if not item_no:
            grid_no = f"{vendor}-{r['style_number'].strip()}-{color_code(color)}"
            item_no = by_grid.get((grid_no, size))
        if not item_no:
            missing.append((r["style_number"], color, r["size"])); continue
        out_rows.append({
            "PO #": r["order_number"], "PO Vendor": vendor,
            "PO Start Ship": r.get("start_date", ""), "PO End Ship": r.get("cancel_date", ""),
            "Item #": item_no, "PO Line Qty": int(float(r["quantity"])),
            "PO Line Unit Cost": float(r["item_price"]),
        })
    if missing:
        print(f"  WARNING: {len(missing)} JOOR line(s) had no matching Heartland item "
              f"(grid #, size): {missing}\n  -> check the items export covers the new grids.")
    write_xlsx(out_path, PO_HEADERS, out_rows, text_cols=("PO #", "Item #"))
    print(f"wrote {out_path} ({len(out_rows)} PO line(s))")

# ------------------------- cli ------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description="JOOR -> Heartland converter (Romi Boutique)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    g = sub.add_parser("grids"); g.add_argument("joor_file"); g.add_argument("-o", default="grids_import.xlsx")
    p = sub.add_parser("po"); p.add_argument("joor_file"); p.add_argument("items_export")
    p.add_argument("-o", default="po_import.xlsx")
    a = ap.parse_args()
    rows, images = read_joor(a.joor_file)
    print(f"read {len(rows)} JOOR line(s) from {a.joor_file}")
    if a.cmd == "grids":
        build_grids(rows, a.o, images)
    else:
        build_po(rows, a.items_export, a.o)

if __name__ == "__main__":
    main()
